public class Third {
	public static void main(String[] args) {
		// Create an array variable named `numbers`
		// with the following content: `[4, 5, 6, 7]`
		// Print the third element of `numbers`
		int[] numbers = {4, 5, 6, 7};
		System.out.println(numbers[2]);
	}
}
