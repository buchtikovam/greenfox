import java.util.HashMap;

public class ShoppingList2 {
	public static void main(String[] args) {
		HashMap<String, Double> listOfPrices = new HashMap<>();
		listOfPrices.put("Milk", 1.07);
		listOfPrices.put("Rice", 1.59);
		listOfPrices.put("Eggs", 3.14);
		listOfPrices.put("Cheese", 12.60);
		listOfPrices.put("Chicken Breasts", 9.40);
		listOfPrices.put("Apples", 2.31);
		listOfPrices.put("Tomato", 2.58);
		listOfPrices.put("Potato", 1.75);
		listOfPrices.put("Onion", 1.10);

		HashMap<String, Integer> bobsList = new HashMap<>();
		bobsList.put("Milk", 3);
		bobsList.put("Rice", 2);
		bobsList.put("Eggs", 2);
		bobsList.put("Cheese", 1);
		bobsList.put("Chicken Breasts", 4);
		bobsList.put("Apples", 1);
		bobsList.put("Tomato", 2);
		bobsList.put("Potato", 1);

		HashMap<String, Integer> aliceList = new HashMap<>();

	}
}
